"""Đọc train/validation/test parquet do stage 3 ghi ra."""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq
from ._schema import SPLIT_NAMES
from .infer_matrix_shape import infer_matrix_shape
from .split_path import split_path

def load_splits(
    splits_dir: str | Path, columns: Sequence[str] = ("user_idx", "item_idx")
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Trả về (train, validation, test). Cột không có trong file bị bỏ qua (vd timestamp)."""
    splits_dir = Path(splits_dir)
    frames = []
    for name in SPLIT_NAMES:
        path = split_path(splits_dir, name)
        if not path.exists():
            raise FileNotFoundError(f"{path} không tồn tại — chạy python scripts/data_pipeline/run_pipeline.py --stages 3 --tag <tag> trước.")
        available = set(pq.ParquetFile(path).schema.names)
        frames.append(pd.read_parquet(path, columns=[c for c in columns if c in available]))
    return frames[0], frames[1], frames[2]
