"""Stage 3: ID mapping, temporal split, and leakage checks."""

from __future__ import annotations

import pandas as pd

from ...config import DataPaths, load_config
from ..leakage import (
    check_no_duplicate_across_splits,
    check_profile_snapshot,
    check_split_temporal_order,
)
from ..mapping import apply_id_mapping, build_id_mappings, save_mappings
from ..split import compute_temporal_cutoffs, save_splits, temporal_split


def map_split(paths: DataPaths, force: bool = False) -> dict:
    """Apply ID mapping, temporal split, and leakage checks.

    Args:
        paths: DataPaths configuration.
        force: Overwrite existing splits.

    Returns:
        Report dictionary with statistics.
    """
    split_config = load_config("data/split")
    train_ratio = split_config["split"]["train_ratio"]
    val_ratio = split_config["split"]["validation_ratio"]
    test_ratio = split_config["split"]["test_ratio"]

    print(f"=== STAGE 3: ID mapping + temporal split + leakage check (tag={paths.tag}) ===")

    if not paths.filtered_path.exists():
        raise FileNotFoundError(
            f"Không tìm thấy {paths.filtered_path} — chạy python scripts/data_pipeline/run_pipeline.py --stages 2 --tag {paths.tag} trước."
        )
    if paths.split_path("train").exists() and not force:
        raise FileExistsError(f"{paths.splits_dir} đã có splits. Dùng --force để ghi đè.")

    df = pd.read_parquet(paths.filtered_path)
    print(f"loaded rows={len(df)} users={df['user_id'].nunique()} items={df['parent_asin'].nunique()}")

    user2id, item2id = build_id_mappings(df)
    df = apply_id_mapping(df, user2id, item2id)
    print(f"id_mapping num_users={len(user2id)} num_items={len(item2id)}")

    save_mappings(user2id, item2id, paths.mapped_dir)
    print(f"saved mappings -> {paths.mapped_dir}")

    cutoff_1, cutoff_2 = compute_temporal_cutoffs(df, train_ratio, val_ratio, test_ratio)
    train, validation, test = temporal_split(df, cutoff_1, cutoff_2)
    print(
        f"temporal_split cutoff_1={cutoff_1} cutoff_2={cutoff_2} "
        f"train={len(train)} val={len(validation)} test={len(test)}"
    )

    check_split_temporal_order(train, validation, test)
    check_no_duplicate_across_splits(train, validation, test)
    check_profile_snapshot(as_of_timestamp=cutoff_1, source_interactions=train)
    print("leakage_check status=PASS (3/3 check)")

    save_splits(train, validation, test, paths.splits_dir)

    print(f"=== STAGE 3 DONE: saved splits -> {paths.splits_dir} ===")

    return {
        "num_users": len(user2id),
        "num_items": len(item2id),
        "train_rows": len(train),
        "val_rows": len(validation),
        "test_rows": len(test),
    }
