"""Tests cho demo module."""
