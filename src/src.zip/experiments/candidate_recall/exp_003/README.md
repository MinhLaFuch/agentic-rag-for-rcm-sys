# exp_003

- timestamp: 2026-10-19T16:09:44.186168+00:00
- seed: 42
- git_commit: None
- runtime_seconds: 130.06
- dataset: {"splits_dir": "D:\\DACNTT\\src\\agentic-rag-for-rcm-sys\\src\\resource\\splits\\multi_domain", "eval_on": "validation", "num_users": 2757103, "num_items": 678281, "id_format": "namespaced", "metadata_coverage": 1.0}

category_oracle results are an upper bound (query built from held-out items); do not report as a result.
